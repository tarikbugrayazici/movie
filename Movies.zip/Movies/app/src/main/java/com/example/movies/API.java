package com.example.movies;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Created by Tarik on 16.11.2019.
 */

public interface API {
    @GET("discover/movie")
    Call<BaseEntity> getMovie(@Query("api_key") String apikey,
                              @Query("language") String language,
                              @Query("sort_by") String sort_by,
                              @Query("include_adult") boolean include_adult,
                              @Query("include_video") boolean include_video,
                              @Query("page") int page);

    @GET("discover/tv")
    Call<BaseEntityTv> getTv(@Query("api_key") String apikey,
                             @Query("language") String language,
                             @Query("sort_by") String sort_by,
                             @Query("page") int page,
                             @Query("timezone") String timezone,
                             @Query("include_null_first_air_dates") boolean include_null_first_air_dates);

    @GET("trending/all/day")
    Call<BaseEntityTrending> getTrendAll(@Query("api_key") String apikey);

    @GET("trending/movie/day")
    Call<BaseEntityTrending> getTrendMovie(@Query("api_key") String apikey);

    @GET("trending/tv/day")
    Call<BaseEntityTrending> getTrendTv(@Query("api_key") String apikey);

    @GET("trending/person/day")
    Call<TabPersonEntity> getTrendPerson(@Query("api_key") String apikey);

    @GET("search/movie")
    Call<SearchMovieBaseEntity> getSearchMovie(@Query("api_key") String apikey,
                                               @Query("language") String language,
                                               @Query("query") String query,
                                               @Query("page") int page,
                                               @Query("include_adult") boolean includeAdult);

    @GET("search/tv")
    Call<SearchTvBaseEntity> getSearchTv(@Query("api_key") String apikey,
                                            @Query("language") String language,
                                            @Query("query") String query,
                                            @Query("page") int page);
}
