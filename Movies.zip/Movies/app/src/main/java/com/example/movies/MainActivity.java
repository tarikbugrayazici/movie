package example.movies;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.movies.BottomNavigationViewHelper;
import com.example.movies.MovieFragment;
import com.example.movies.SearchFragment;
import com.example.movies.TrendingFragment;
import com.example.movies.TvFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;


public class MainActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottom_nav);
        bottomNavigationView.setOnNavigationItemSelectedListener(this);
        BottomNavigationViewHelper.disableShiftMode(bottomNavigationView);

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Fragment selectedFragment = null;
        if (item.getItemId() == R.id.movie) {
            selectedFragment = new MovieFragment();
        } else if (item.getItemId() == R.id.tv) {
            selectedFragment = new TvFragment();
        } else if (item.getItemId() == R.id.search) {
            selectedFragment = new SearchFragment();
        } else if (item.getItemId() == R.id.trending) {
            selectedFragment = new TrendingFragment();
        }
        replaceFragment(selectedFragment);
        return true;
    }

    private void replaceFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.frame_container, fragment)
                .commit();
    }

}
