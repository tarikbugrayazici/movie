package com.example.movies;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.MovieAdapterHolder> {
    private ArrayList<Movie> list;
    private Context context;

    public MovieAdapter(Context context, ArrayList<Movie> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public MovieAdapter.MovieAdapterHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MovieAdapterHolder(LayoutInflater.from(context).inflate(R.layout.layout_movie_item, parent, false));
    }

    @Override
    public void onBindViewHolder(MovieAdapter.MovieAdapterHolder holder, int position) {
        final Movie movie = list.get(position);
        String url = "https://image.tmdb.org/t/p/w500";
        Glide.with(context).load(url + movie.getPoster_path()).centerCrop().into(holder.imageViewOne);
        //Glide.with(context).load(url + movie.getPoster_path()).centerCrop().into(holder.imageViewTwo);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MovieAdapterHolder extends RecyclerView.ViewHolder {
        ImageView imageViewOne, imageViewTwo;
        public MovieAdapterHolder(View itemView) {
            super(itemView);
            imageViewOne = (ImageView) itemView.findViewById(R.id.img_view_one);
            //imageViewTwo = (ImageView) itemView.findViewById(R.id.img_view_two);
        }
    }

}

