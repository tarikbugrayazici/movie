package com.example.movies;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static java.security.AccessController.getContext;

/**
 * Created by Tarik on 16.11.2019.
 */

public class MovieFragment extends Fragment {
    private RecyclerView recyclerView;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.movie_fragment_layout, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = (RecyclerView) view.findViewById(R.id.movie_recycler_view);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(),2));
        fetchMovies();
    }

    private void fetchMovies() {
        API retrofit = RetroFitService.getRetrofit().create(API.class);
        Call<BaseEntity> call = retrofit.getMovie("788a71cfbb2953df3cc3b1e7531ef259",
                "en-US", "popularity.desc", false,
                false, 1);
        call.enqueue(new Callback<BaseEntity>() {
            @Override
            public void onResponse(@NonNull Call<BaseEntity> call, @NonNull Response<BaseEntity> response) {
                response.body().getResults();
                setRecyclerView(response.body().getResults());
            }

            @Override
            public void onFailure(@NonNull Call<BaseEntity> call,@NonNull Throwable t) {
                System.out.println("hataaaaaaaaaaaa");
            }
        });
    }
    private void setRecyclerView(ArrayList<Movie> list){
        ArrayList<Movie> movies = new ArrayList<>();
        movies.addAll(list);
        MovieAdapter adapter =new MovieAdapter(getContext(),movies);
        recyclerView.setAdapter(adapter);

    }


}
