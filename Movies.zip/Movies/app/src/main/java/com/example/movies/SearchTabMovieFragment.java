package com.example.movies;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class SearchTabMovieFragment extends Fragment {
    Button button;
    String text;
    RecyclerView recyclerView;
    EditText editText;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_search_tab_movie,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = (RecyclerView)view.findViewById(R.id.search_movie_recycler_view);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(),2));
        editText= (EditText)view.findViewById(R.id.search_edit_text_movie);
        button = (Button)view.findViewById(R.id.button_tab_search_movie);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               text = editText.getText().toString();
                fetchNamesMovie();
            }
        });

    }

    private void fetchNamesMovie(){
        API retrofit = RetroFitService.getRetrofit().create(API.class);
        Call<SearchMovieBaseEntity> call = retrofit.getSearchMovie("788a71cfbb2953df3cc3b1e7531ef259",
                "en-US", text,1,false);
        call.enqueue(new Callback<SearchMovieBaseEntity>() {
            @Override
            public void onResponse(@NonNull Call<SearchMovieBaseEntity> call, @NonNull Response<SearchMovieBaseEntity> response) {
                response.body().getResults();
                setRecyclerView(response.body().getResults());
            }

            @Override
            public void onFailure(@NonNull Call<SearchMovieBaseEntity> call,@NonNull Throwable t) {
                    System.out.println("hata11");
            }
        });
    }

    private void setRecyclerView(ArrayList<SearchMovie> list){
        ArrayList<SearchMovie> searchMovies = new ArrayList<>();
        searchMovies.addAll(list);
        SearchTabMovieAdapter  adapter = new SearchTabMovieAdapter(getContext(),searchMovies);
        recyclerView.setAdapter(adapter);
    }
}
