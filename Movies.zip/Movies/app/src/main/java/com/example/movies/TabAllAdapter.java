package com.example.movies;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class TabAllAdapter extends RecyclerView.Adapter<TabAllAdapter.TabAllAdapterHolder> {
    private Context context;
    private ArrayList<Trending> list;

    public TabAllAdapter(Context context, ArrayList<Trending> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public TabAllAdapterHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new TabAllAdapterHolder(LayoutInflater.from(context)
                .inflate(R.layout.layout_tab_all_item, parent, false));
    }

    @Override
    public void onBindViewHolder(TabAllAdapterHolder holder, int position) {
        final Trending trending = list.get(position);
        String url = "https://image.tmdb.org/t/p/w500";
        Glide.with(context).load(url+trending.getPoster_path())
                .centerCrop().into(holder.tabİmage);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class TabAllAdapterHolder extends RecyclerView.ViewHolder {
        ImageView tabİmage;
        public TabAllAdapterHolder(View itemView) {
            super(itemView);
            tabİmage = (ImageView) itemView.findViewById(R.id.img_view_tab_all);

        }
    }
}
