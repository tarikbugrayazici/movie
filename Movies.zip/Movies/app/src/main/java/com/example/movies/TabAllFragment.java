package com.example.movies;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TabAllFragment extends Fragment {
    RecyclerView recyclerView;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_tab_all, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = (RecyclerView) view.findViewById(R.id.tab_all_recycler_view);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));
        fetchTabAllFragment();
    }

    public void fetchTabAllFragment() {
        API retrofit = RetroFitService.getRetrofit().create(API.class);
        Call<BaseEntityTrending> call = retrofit.getTrendAll("788a71cfbb2953df3cc3b1e7531ef259");
        call.enqueue(new Callback<BaseEntityTrending>() {
            @Override
            public void onResponse(@NonNull Call<BaseEntityTrending> call, @NonNull Response<BaseEntityTrending> response) {
                response.body().getResults();
                setRecyclerView(response.body().getResults());
            }

            @Override
            public void onFailure(@NonNull Call<BaseEntityTrending> call, @NonNull Throwable t) {
                System.out.println("hata");

            }
        });
    }

    private void setRecyclerView(ArrayList<Trending> list) {
        ArrayList<Trending> trendings = new ArrayList<>();
        trendings.addAll(list);
        TabAllAdapter adapter = new TabAllAdapter(getContext(), trendings);
        recyclerView.setAdapter(adapter);
    }
}
