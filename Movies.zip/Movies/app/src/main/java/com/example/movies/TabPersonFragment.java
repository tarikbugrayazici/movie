package com.example.movies;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class TabPersonFragment extends Fragment {
    RecyclerView recyclerView;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        return  inflater.inflate(R.layout.fragment_tab_person, container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = (RecyclerView)view.findViewById(R.id.tab_person_recycler_view);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(),2));
        fetchPerson();
    }
    private void fetchPerson(){
        API retrofit = RetroFitService.getRetrofit().create(API.class);
        Call<TabPersonEntity> call = retrofit.getTrendPerson("788a71cfbb2953df3cc3b1e7531ef259");
        call.enqueue(new Callback<TabPersonEntity>() {
            @Override
            public void onResponse(Call<TabPersonEntity> call, Response<TabPersonEntity> response) {
                response.body().getResults();
                setRecyclerView(response.body().getResults());
            }

            @Override
            public void onFailure(Call<TabPersonEntity> call, Throwable t) {

            }
        });
    }
    private void setRecyclerView(ArrayList<Person> list){
        ArrayList<Person> people = new ArrayList<>();
        people.addAll(list);
        TabPersonAdapter adapter = new TabPersonAdapter(getContext(),people);
        recyclerView.setAdapter(adapter);

    }
}
