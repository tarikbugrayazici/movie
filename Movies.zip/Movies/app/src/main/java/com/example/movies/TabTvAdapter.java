package com.example.movies;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class TabTvAdapter extends RecyclerView.Adapter<TabTvAdapter.TabTvAdapterHolder>{
    private Context context;
    private ArrayList<Trending> list;

    public TabTvAdapter(Context context, ArrayList<Trending> list){
        this.context = context;
        this.list =list;
    }

    @Override
    public TabTvAdapter.TabTvAdapterHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new TabTvAdapterHolder(LayoutInflater.from(context)
                .inflate(R.layout.layout_tab_tv_item, parent, false));
    }

    @Override
    public void onBindViewHolder(TabTvAdapterHolder holder, int position) {
        final Trending trending = list.get(position);
        String url = "https://image.tmdb.org/t/p/w500";
        Glide.with(context).load(url+trending.getPoster_path())
                .centerCrop().into(holder.imgTabTv);

    }


    @Override
    public int getItemCount() {
        return list.size();
    }

    public class TabTvAdapterHolder extends RecyclerView.ViewHolder {
        ImageView imgTabTv;
        public TabTvAdapterHolder(View itemView) {
            super(itemView);
            imgTabTv = (ImageView)itemView.findViewById(R.id.img_view_tab_tv);
        }
    }
}
