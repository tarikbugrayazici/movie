package com.example.movies;

import java.util.ArrayList;

public class Tv {
    private String original_name;
    private ArrayList<Integer> genre_ids;
    private String name;
    private Number popularty;
    private ArrayList<String> origin_country;
    private int vote_count;
    private String first_air_date;
    private String backdrop_path;
    private String original_language;
    private int id;
    private Number vote_average;
    private String overview;
    private String poster_path;

    public String getOriginal_name() {
        return original_name;
    }

    public ArrayList<Integer> getGenre_ids() {
        return genre_ids;
    }

    public String getName() {
        return name;
    }

    public Number getPopularty() {
        return popularty;
    }

    public ArrayList<String> getOrigin_country() {
        return origin_country;
    }

    public int getVote_count() {
        return vote_count;
    }

    public String getFirst_air_date() {
        return first_air_date;
    }

    public String getBackdrop_path() {
        return backdrop_path;
    }

    public String getOriginal_language() {
        return original_language;
    }

    public int getId() {
        return id;
    }

    public Number    getVote_average() {
        return vote_average;
    }

    public String getOverview() {
        return overview;
    }

    public String getPoster_path() {
        return poster_path;
    }
}
