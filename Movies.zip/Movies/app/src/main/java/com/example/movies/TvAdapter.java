package com.example.movies;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class TvAdapter extends RecyclerView.Adapter<TvAdapter.TvAdapterHolder> {
    private Context context;
    private ArrayList<Tv> list;

    public TvAdapter(Context context,ArrayList<Tv> list){
        this.context = context;
        this.list = list;
    }
    @Override
    public TvAdapterHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new TvAdapterHolder(LayoutInflater.from(context).inflate(R.layout.layout_tv_item, parent,false));
    }

    @Override
    public void onBindViewHolder(TvAdapterHolder holder, int position) {
        final Tv tv = list.get(position);
        String url = "https://image.tmdb.org/t/p/w500";
        Glide.with(context).load(url+tv.getPoster_path()).centerCrop().into(holder.imageViewTv);
        //holder.de.setText(tv.getName());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class TvAdapterHolder extends RecyclerView.ViewHolder {
        ImageView imageViewTv;
        TextView de;
        public TvAdapterHolder(View itemView) {
            super(itemView);
            imageViewTv = (ImageView)itemView.findViewById(R.id.img_view_tv);
            //de = (TextView)itemView.findViewById(R.id.deneme);
        }
    }
}
